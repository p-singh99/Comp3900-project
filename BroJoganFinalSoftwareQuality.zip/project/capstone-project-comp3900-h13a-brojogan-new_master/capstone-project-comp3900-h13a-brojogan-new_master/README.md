# lucidchart link
https://app.lucidchart.com/invitations/accept/5b2bbb25-7a81-4b54-b992-9e38d8f071d8

# Frontend Installation

  - Install node.
  - cd frontend/brojogan-podcast
  - npm install
  
  Starting Frontend
  
    - cd frontend/brojogan-podcast
    - npm start
    
# Database stuff
See [app/database/details.md](app/database/README.md)

